package pkg

import (
	"strings"
	"testing"
)

func TestFoo(t *testing.T) {
	strings.Replace("", "", "", 1) //@ diag(`doesn't have side effects`)
}

func BenchmarkFoo(b *testing.B) {
	strings.Replace("", "", "", 1)
}

func doBenchmark(s string, b *testing.B) {
	strings.Replace("", "", "", 1)
}

func BenchmarkBar(b *testing.B) {
	doBenchmark("", b)
}
