// Copyright 2023 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package misc

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"testing"

	"github.com/google/go-cmp/cmp"
	"golang.org/x/telemetry/counter"
	"golang.org/x/telemetry/counter/countertest"
	"golang.org/x/tools/gopls/internal/protocol"
	"golang.org/x/tools/gopls/internal/protocol/command"
	"golang.org/x/tools/gopls/internal/server"
	. "golang.org/x/tools/gopls/internal/test/integration"
)

// Test that gopls prompts for telemetry only when it is supposed to.
func TestTelemetryPrompt_Conditions(t *testing.T) {
	const src = `
-- go.mod --
module mod.com

go 1.12
-- main.go --
package main

func main() {
}
`

	for _, enabled := range []bool{true, false} {
		t.Run(fmt.Sprintf("telemetryPrompt=%v", enabled), func(t *testing.T) {
			for _, initialMode := range []string{"", "local", "off", "on"} {
				t.Run(fmt.Sprintf("initial_mode=%s", initialMode), func(t *testing.T) {
					modeFile := filepath.Join(t.TempDir(), "mode")
					if initialMode != "" {
						if err := os.WriteFile(modeFile, []byte(initialMode), 0666); err != nil {
							t.Fatal(err)
						}
					}
					WithOptions(
						Modes(Default), // no need to run this in all modes
						EnvVars{
							server.GoplsConfigDirEnvvar:        t.TempDir(),
							server.FakeTelemetryModefileEnvvar: modeFile,
						},
						Settings{
							"telemetryPrompt": enabled,
						},
					).Run(t, src, func(t *testing.T, env *Env) {
						wantPrompt := enabled && (initialMode == "" || initialMode == "local")
						expectation := ShownMessageRequest(".*Would you like to enable Go telemetry?")
						if !wantPrompt {
							expectation = Not(expectation)
						}
						env.OnceMet(
							CompletedWork(server.TelemetryPromptWorkTitle, 1, true),
							expectation,
						)
					})
				})
			}
		})
	}
}

// Test that responding to the telemetry prompt results in the expected state.
func TestTelemetryPrompt_Response(t *testing.T) {
	if !countertest.SupportedPlatform {
		t.Skip("requires counter support")
	}

	const src = `
-- go.mod --
module mod.com

go 1.12
-- main.go --
package main

func main() {
}
`

	var (
		acceptanceCounter = "gopls/telemetryprompt/accepted"
		declinedCounter   = "gopls/telemetryprompt/declined"
		attempt1Counter   = "gopls/telemetryprompt/attempts:1"
		allCounters       = []string{acceptanceCounter, declinedCounter, attempt1Counter}
	)

	// We must increment counters in order for the initial reads below to
	// succeed.
	//
	// TODO(rfindley): ReadCounter should simply return 0 for uninitialized
	// counters.
	for _, name := range allCounters {
		counter.New(name).Inc()
	}

	readCounts := func(t *testing.T) map[string]uint64 {
		t.Helper()
		counts := make(map[string]uint64)
		for _, name := range allCounters {
			count, err := countertest.ReadCounter(counter.New(name))
			if err != nil {
				t.Fatalf("ReadCounter(%q) failed: %v", name, err)
			}
			counts[name] = count
		}
		return counts
	}

	tests := []struct {
		name       string // subtest name
		response   string // response to choose for the telemetry dialog
		wantMode   string // resulting telemetry mode
		wantMsg    string // substring contained in the follow-up popup (if empty, no popup is expected)
		wantInc    uint64 // expected 'prompt accepted' counter increment
		wantCounts map[string]uint64
	}{
		{"yes", server.TelemetryYes, "on", "uploading is now enabled", 1, map[string]uint64{
			acceptanceCounter: 1,
			declinedCounter:   0,
			attempt1Counter:   1,
		}},
		{"no", server.TelemetryNo, "", "", 0, map[string]uint64{
			acceptanceCounter: 0,
			declinedCounter:   1,
			attempt1Counter:   1,
		}},
		{"empty", "", "", "", 0, map[string]uint64{
			acceptanceCounter: 0,
			declinedCounter:   0,
			attempt1Counter:   1,
		}},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			initialCounts := readCounts(t)
			modeFile := filepath.Join(t.TempDir(), "mode")
			msgRE := regexp.MustCompile(".*Would you like to enable Go telemetry?")
			respond := func(m *protocol.ShowMessageRequestParams) (*protocol.MessageActionItem, error) {
				if msgRE.MatchString(m.Message) {
					for _, item := range m.Actions {
						if item.Title == test.response {
							return &item, nil
						}
					}
					if test.response != "" {
						t.Errorf("action item %q not found", test.response)
					}
				}
				return nil, nil
			}
			WithOptions(
				Modes(Default), // no need to run this in all modes
				EnvVars{
					server.GoplsConfigDirEnvvar:        t.TempDir(),
					server.FakeTelemetryModefileEnvvar: modeFile,
				},
				Settings{
					"telemetryPrompt": true,
				},
				MessageResponder(respond),
			).Run(t, src, func(t *testing.T, env *Env) {
				var postConditions []Expectation
				if test.wantMsg != "" {
					postConditions = append(postConditions, ShownMessage(test.wantMsg))
				}
				env.OnceMet(
					CompletedWork(server.TelemetryPromptWorkTitle, 1, true),
					postConditions...,
				)
				gotMode := ""
				if contents, err := os.ReadFile(modeFile); err == nil {
					gotMode = string(contents)
				} else if !os.IsNotExist(err) {
					t.Fatal(err)
				}
				if gotMode != test.wantMode {
					t.Errorf("after prompt, mode=%s, want %s", gotMode, test.wantMode)
				}

				// We increment the acceptance counter when checking the prompt file
				// before prompting, so start a second, transient gopls session and
				// verify that the acceptance counter is incremented.
				env2 := ConnectGoplsEnv(t, env.Ctx, env.Sandbox, env.Editor.Config(), env.Server)
				env2.Await(CompletedWork(server.TelemetryPromptWorkTitle, 1, true))
				if err := env2.Editor.Close(env2.Ctx); err != nil {
					t.Errorf("closing second editor: %v", err)
				}

				gotCounts := readCounts(t)
				for k := range gotCounts {
					gotCounts[k] -= initialCounts[k]
				}
				if diff := cmp.Diff(test.wantCounts, gotCounts); diff != "" {
					t.Errorf("counter mismatch (-want +got):\n%s", diff)
				}
			})
		})
	}
}

// Test that we stop asking about telemetry after the user ignores the question
// 5 times.
func TestTelemetryPrompt_GivingUp(t *testing.T) {
	const src = `
-- go.mod --
module mod.com

go 1.12
-- main.go --
package main

func main() {
}
`

	// For this test, we want to share state across gopls sessions.
	modeFile := filepath.Join(t.TempDir(), "mode")
	configDir := t.TempDir()

	const maxPrompts = 5 // internal prompt limit defined by gopls

	for i := 0; i < maxPrompts+1; i++ {
		WithOptions(
			Modes(Default), // no need to run this in all modes
			EnvVars{
				server.GoplsConfigDirEnvvar:        configDir,
				server.FakeTelemetryModefileEnvvar: modeFile,
			},
			Settings{
				"telemetryPrompt": true,
			},
		).Run(t, src, func(t *testing.T, env *Env) {
			wantPrompt := i < maxPrompts
			expectation := ShownMessageRequest(".*Would you like to enable Go telemetry?")
			if !wantPrompt {
				expectation = Not(expectation)
			}
			env.OnceMet(
				CompletedWork(server.TelemetryPromptWorkTitle, 1, true),
				expectation,
			)
		})
	}
}

// Test that gopls prompts for telemetry only when it is supposed to.
func TestTelemetryPrompt_Conditions2(t *testing.T) {
	const src = `
-- go.mod --
module mod.com

go 1.12
-- main.go --
package main

func main() {
}
`
	modeFile := filepath.Join(t.TempDir(), "mode")
	WithOptions(
		Modes(Default), // no need to run this in all modes
		EnvVars{
			server.GoplsConfigDirEnvvar:        t.TempDir(),
			server.FakeTelemetryModefileEnvvar: modeFile,
		},
		Settings{
			// off because we are testing
			// if we can trigger the prompt with command.
			"telemetryPrompt": false,
		},
	).Run(t, src, func(t *testing.T, env *Env) {
		cmd, err := command.NewMaybePromptForTelemetryCommand("prompt")
		if err != nil {
			t.Fatal(err)
		}
		var result error
		env.ExecuteCommand(&protocol.ExecuteCommandParams{
			Command: cmd.Command,
		}, &result)
		if result != nil {
			t.Fatal(err)
		}
		expectation := ShownMessageRequest(".*Would you like to enable Go telemetry?")
		env.OnceMet(
			CompletedWork(server.TelemetryPromptWorkTitle, 2, true),
			expectation,
		)
	})
}
