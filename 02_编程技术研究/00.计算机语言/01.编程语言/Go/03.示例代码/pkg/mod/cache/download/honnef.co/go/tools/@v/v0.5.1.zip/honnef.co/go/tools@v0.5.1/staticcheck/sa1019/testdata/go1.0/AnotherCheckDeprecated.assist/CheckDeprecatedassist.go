// Package pkg is a nice package.
//
// Deprecated: Alas, it is deprecated.
package AnotherCheckDeprecatedassist

func Fn() {}
