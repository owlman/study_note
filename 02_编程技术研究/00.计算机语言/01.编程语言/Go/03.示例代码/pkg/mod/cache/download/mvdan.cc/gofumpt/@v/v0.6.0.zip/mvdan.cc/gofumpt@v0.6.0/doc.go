// Copyright (c) 2023, Daniel Martí <mvdan@mvdan.cc>
// See LICENSE for licensing information

// gofumpt enforces a stricter format than gofmt, while being backwards compatible.
package main
